# Deep Research Index

| DR_ID | File | Gate | Decision Unlocked | Status |
| --- | --- | --- | --- | --- |
| DR-06 | docs/DR-06_insurance.md | Gate 1 | TBD | PENDING |
| DR-07 | docs/DR-07_security.md | Gate 1 | TBD | PENDING |
| DR-08 | docs/DR-08_music_licensing.md | Gate 4 | TBD | PENDING |
| DR-09 | docs/DR-09_pos_stack.md | Gate 3 | TBD | PENDING |
| DR-10 | docs/DR-10_distribution_cogs.md | Gate 2 | TBD | PENDING |
| DR-11 | docs/DR-11_kitchen_lite.md | Gate 1 | TBD | PENDING |
| DR-12 | docs/DR-12_labor_wages.md | Gate 2 | TBD | PENDING |
| DR-13 | docs/DR-13_marketing_launch.md | Gate 4 | TBD | PENDING |
| DR-14 | docs/DR-14_leagues_tournaments.md | Gate 5 | TBD | PENDING |
| DR-15 | docs/DR-15_memberships.md | Gate 5 | TBD | PENDING |
| DR-16 | docs/DR-16_equipment_procurement.md | Gate 3 | TBD | PENDING |
| DR-17 | docs/DR-17_utilities_hvac.md | Gate 1 | TBD | PENDING |
| DR-18 | docs/DR-18_code_ada_egress.md | Gate 1 | TBD | PENDING |
| DR-19 | docs/DR-19_finance_sba_banks.md | Gate 2 | TBD | PENDING |
| DR-20 | docs/DR-20_ops_binder.md | Gate 4 | TBD | PENDING |
